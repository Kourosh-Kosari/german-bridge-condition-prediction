# Bridge Condition Analysis

A GitHub Pages website for a civil-engineering / data-science project focused on bridge condition classification.

## Structure

- `index.html` — website homepage
- `style.css` — responsive website styling
- `script.js` — optional JavaScript entry point
- `data/` — datasets
- `notebooks/` — Jupyter notebooks
- `models/` — trained model files
- `images/` — project figures

## GitHub Pages

1. Create a **public** GitHub repository, for example `bridge-condition-analysis`.
2. Upload all files and folders from this project.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`.
6. Save.
7. GitHub will publish the site at:

`https://YOUR-USERNAME.github.io/bridge-condition-analysis/`

## Important

The performance numbers on the website are placeholders. Replace them with the actual metrics from your trained model rather than publishing invented results.
